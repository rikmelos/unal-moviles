package com.example.android.datafrominternet;

/**
 * Created by Richard on 26/11/2017.
 */

public class Info {
    public String name, city, address;

    Info() {}

    public Info(String name, String city, String address) {
        this.name = name;
        this.city = city;
        this.address = address;
    }
}
