package co.edu.unal.tictactoe;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceManager;
import android.widget.Toast;




/**
 * Created by richa on 16/10/2017.
 */

public class Settings extends PreferenceActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.preferences);

        final SharedPreferences prefs =
                PreferenceManager.getDefaultSharedPreferences(getBaseContext());

        final ListPreference difficultyLevelPref = (ListPreference) findPreference("difficulty_level");
        String difficulty = prefs.getString("difficulty_level",
                getResources().getString(R.string.difficulty_expert));
        difficultyLevelPref.setSummary((CharSequence) difficulty);

        difficultyLevelPref.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                difficultyLevelPref.setSummary((CharSequence) newValue);

                // Since we are handling the pref, we must save it
                SharedPreferences.Editor ed = prefs.edit();
                ed.putString("difficulty_level", newValue.toString());
                ed.commit();
                return true;
            }
        });

        final CheckBoxPreference soundPref = (CheckBoxPreference)findPreference("sound");
        soundPref.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object o) {
                SharedPreferences.Editor ed = prefs.edit();
                Toast.makeText(getApplicationContext(),o.toString()=="true" ? "Sound On": "Sound Off", Toast.LENGTH_SHORT).show();
                ed.putBoolean("sound",new Boolean(o.toString()));
                ed.commit();
                return true;
            }
        });

    }
}









/*
    <?xml version="1.0" encoding="utf-8"?>
<menu xmlns:android="http://schemas.android.com/apk/res/android"
        xmlns:app="http://schemas.android.com/apk/res-auto"
        xmlns:tools="http://schemas.android.com/tools"
        tools:context="co.edu.unal.tictactoe.AndroidTicTacToeActivity">
        >

<item
        android:id="@+id/empty"
                android:icon="@drawable/ic_launcher"
                android:orderInCategory="101"
                app:showAsAction="always"
                android:title="menu">
<menu>
<item android:id="@+id/new_game"
        android:title="New Game"
        android:icon="@drawable/ic_playingagain_tictactoe"
        android:orderInCategory="100"
        app:showAsAction="always|withText" />
<item android:id="@+id/ai_difficulty"
        android:title="Difficulty"
        android:icon="@drawable/difficulty_level"
        android:orderInCategory="100"
        app:showAsAction="always|withText"/>
<item
                android:orderInCategory="100"
                        android:id="@+id/reset_scores"
                        android:title="Reset Scores"
                        android:icon="@drawable/quit_game"
                        app:showAsAction="always|withText" />
<item
                android:orderInCategory="100"
                        android:id="@+id/about"
                        android:title="About"
                        android:icon="@drawable/my_about"
                        app:showAsAction="always|withText" />
</menu>
</item>
</menu>*/
