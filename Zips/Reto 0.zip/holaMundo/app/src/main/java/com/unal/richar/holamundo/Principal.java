package com.unal.richar.holamundo;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by richa on 7/08/2017.
 */

public class Principal extends Activity {
    public void onCreate(Bundle bundle){
        super.onCreate(bundle);

        setContentView(R.layout.principal);
    }
}
